<?php

return array(
    'store_path' => public_path("/"),
);
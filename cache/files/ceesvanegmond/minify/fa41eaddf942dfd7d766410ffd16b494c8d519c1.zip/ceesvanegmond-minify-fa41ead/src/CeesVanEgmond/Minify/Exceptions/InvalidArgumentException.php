<?php  namespace CeesVanEgmond\Minify\Exceptions; 

class InvalidArgumentException extends \Exception{}

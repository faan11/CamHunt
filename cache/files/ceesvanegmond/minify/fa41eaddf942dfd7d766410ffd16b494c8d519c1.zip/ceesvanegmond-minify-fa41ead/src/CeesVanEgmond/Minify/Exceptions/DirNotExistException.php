<?php namespace CeesVanEgmond\Minify\Exceptions;

class DirNotExistException extends \Exception {}

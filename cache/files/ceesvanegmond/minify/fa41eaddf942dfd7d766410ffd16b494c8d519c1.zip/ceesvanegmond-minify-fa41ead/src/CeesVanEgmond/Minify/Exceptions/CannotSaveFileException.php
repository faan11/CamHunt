<?php  namespace CeesVanEgmond\Minify\Exceptions; 

class CannotSaveFileException extends \Exception{}

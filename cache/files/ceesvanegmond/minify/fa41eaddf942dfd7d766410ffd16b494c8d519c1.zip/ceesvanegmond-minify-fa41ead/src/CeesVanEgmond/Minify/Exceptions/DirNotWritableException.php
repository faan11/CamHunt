<?php  namespace CeesVanEgmond\Minify\Exceptions; 

class DirNotWritableException extends \Exception {}

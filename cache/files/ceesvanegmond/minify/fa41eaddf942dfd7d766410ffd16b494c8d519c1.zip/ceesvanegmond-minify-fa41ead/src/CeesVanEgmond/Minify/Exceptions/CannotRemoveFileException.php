<?php  namespace CeesVanEgmond\Minify\Exceptions; 

class CannotRemoveFileException extends \Exception{}

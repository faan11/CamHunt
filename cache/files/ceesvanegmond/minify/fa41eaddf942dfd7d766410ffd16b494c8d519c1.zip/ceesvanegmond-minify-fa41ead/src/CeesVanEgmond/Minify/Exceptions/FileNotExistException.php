<?php namespace CeesVanEgmond\Minify\Exceptions;

class FileNotExistException extends \Exception {}

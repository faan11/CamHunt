Simple QrCode
=============

##Change Log

#### 1.1.1
* Update dependencies.
* Corrected some composer file issues.
* Added some missing Laravel information to the QrCode Service Provider.

####1.1.0
* Added the ability to change the character encoding.
/* This line should not be there later. */

var test;
var test;
var test;

/*
 Neither should this one.
*/

var test;
var test;

        /*
         Or this one.
         */

var test;


/**
 *
 * Even if this one is special!
 *
 */
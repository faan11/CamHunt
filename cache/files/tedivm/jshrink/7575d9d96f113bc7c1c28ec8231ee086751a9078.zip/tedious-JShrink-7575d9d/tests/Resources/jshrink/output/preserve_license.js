/*!
 This comment should be preserved.
 */
var test;var test;
/*!
 This comment should be preserved.
 */
var test;
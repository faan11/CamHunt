<?php

date_default_timezone_set('America/Los_Angeles');
require __DIR__ . '/../vendor/autoload.php';
